package com.samu.memecontest;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
